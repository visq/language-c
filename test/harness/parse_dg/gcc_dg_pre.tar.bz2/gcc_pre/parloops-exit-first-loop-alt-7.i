# 1 "parloops-exit-first-loop-alt-7.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 31 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 32 "<command-line>" 2
# 1 "parloops-exit-first-loop-alt-7.c"





void
f (int n, unsigned int *__restrict__ a, unsigned int *__restrict__ b,
   unsigned int *__restrict__ c)
{
  int i;

  for (i = 0; i < n; ++i)
    c[i] = a[i] + b[i];
}
