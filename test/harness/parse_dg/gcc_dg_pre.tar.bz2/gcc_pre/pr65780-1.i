# 1 "pr65780-1.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 31 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 32 "<command-line>" 2
# 1 "pr65780-1.c"




int optopt;

int
main ()
{
  optopt = 4;
  return 0;
}
